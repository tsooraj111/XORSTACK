from django.shortcuts import render,HttpResponse
from app.forms import empform
from app.models import emp
# Create your views here.

def insert(request):
    var=empform()
    if request.method=='POST':
        a=empform(request.POST)
        if a.is_valid():
            a.save()
            return HttpResponse("data is stored in table")
    return render(request,'view.html',{'var':var})

def read(request):
    var=emp.objects.filter()
    return render(request,'read.html',{'data':var})

def update(request,pk):
    a=emp.objects.get(id=pk)
    var=empform(instance=a)
    if request.method=='POST':
        a=empform(request.POST,instance=a)
        if a.is_valid():
            a.save()
            return HttpResponse("data is updated in table")
    return render(request,'view.html',{'var':var})

def delete(request,pk):
    var=emp.objects.filter(id=pk).delete()
    return HttpResponse('the data is deleted')