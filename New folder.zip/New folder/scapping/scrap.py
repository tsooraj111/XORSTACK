import requests

from bs4 import BeautifulSoup
url="https://stackoverflow.com/questions/tagged/python"
r=requests.get(url)
list_name=[]
soup=BeautifulSoup(r.content,'html.parser')
element_name=soup.find_all('h3', class_="s-post-summary--content-title")
list_name=[element.text.strip() for element in element_name]
for name in list_name:
    print(name)
